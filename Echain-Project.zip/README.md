# Echain Architecture Project

## Overview
This project integrates blockchain, machine learning, and containerized microservices to build a smart equipment tracking system.

### Technologies:
- **Frontend**: React, TypeScript, Material UI
- **Backend**: Node.js, Express, Web3.js
- **Blockchain**: Ethereum Smart Contracts
- **Machine Learning**: Python (RandomForestClassifier)
- **Deployment**: Docker

## Structure
- `backend/`: Backend API
- `frontend/`: Frontend React App
- `ml/`: Machine Learning scripts
- `smart-contract/`: Solidity Smart Contracts

## How to Run
1. Clone the repository.
2. Use `docker-compose up` to start all services.